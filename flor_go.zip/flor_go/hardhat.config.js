import * as dotenv from "dotenv";
import "@typechain/hardhat";
import "@nomiclabs/hardhat-ethers";
import "@nomiclabs/hardhat-waffle";
import "@nomiclabs/hardhat-etherscan";
import "solidity-coverage";
import "hardhat-gas-reporter";
import "hardhat-abi-exporter";
import path from "path";
import "@openzeppelin/hardhat-upgrades";
import "@openzeppelin/hardhat-defender";

dotenv.config({ path: path.join(__dirname, ".env") });

require("hardhat-contract-sizer");
require("hardhat-abi-exporter");

export default {
  defender: {
    apiKey: process.env.DEFENDER_TEAM_API_KEY,
    apiSecret: process.env.DEFENDER_TEAM_API_SECRET_KEY,
  },
  networks: {
    hardhat: {
      allowUnlimitedContractSize: false,
      chainId: 31337,
      gas: 5000000, // "auto",  COMMENT: removed due to coverage and testing error messages inconsistencies
      forking: {
        enabled: false,
        url: `https://eth-rinkeby.alchemyapi.io/v2/${process.env.RINKEBY_ALCHEMY_API_KEY}`,
      },
    },
    mainnet: {
      timeout: 100000,
      pollingInterval: 7000,
      gasPrice: 100000000000,
      // gasLimit: 250000,
      url: `https://eth-mainnet.alchemyapi.io/v2/${process.env.MAINNET_ALCHEMY_API_KEY}`,
      accounts: { mnemonic: process.env.MAINNET_MNEMONIC ?? "" },
    },
    arbitrum: {
      timeout: 100000,
      pollingInterval: 7000,
      gasPrice: 100000000000,
      // gasLimit: 250000,
      url: `https://arb-mainnet.g.alchemy.com/v2/${process.env.ARBITRUM_ALCHEMY_API_KEY}`,
      // ETH MAINNET and ARBITRUM (mainnet) share same MNEMONIC (wallets)
      accounts: { mnemonic: process.env.MAINNET_MNEMONIC ?? "" },
    },
    goerli: {
      // url: `https://goerli.infura.io/v3/${process.env.GOERLI_INFURA_API_KEY}`,
      gasPrice: 95000000000,
      url: `https://eth-goerli.alchemyapi.io/v2/${process.env.GOERLI_ALCHEMY_API_KEY}`,
      accounts: { mnemonic: process.env.GOERLI_MNEMONIC ?? "" },
    },
    arbitrumTestnet: {
      timeout: 100000,
      pollingInterval: 7000,
      gasLimit: 30000000000, // 100000000, // 0.1 gwei
      url: `https://arb-goerli.g.alchemy.com/v2/${process.env.ARBITRUM_GOERLI_ALCHEMY_API_KEY}`,
      // ETH GOERLI and ARBITRUM GOERLI share same MNEMONIC (wallets)
      accounts: { mnemonic: process.env.GOERLI_MNEMONIC ?? "" },
    },
  },
  etherscan: {
    apiKey: {
      mainnet: process.env.ETHERSCAN_API_KEY,
      goerli: process.env.ETHERSCAN_API_KEY,
      arbitrum: process.env.ARBISCAN_API_KEY,
      arbitrumTestnet: process.env.ARBISCAN_API_KEY,
    },
  },
  solidity: {
    compilers: [
      {
        version: "0.8.17",
        settings: {
          metadata: {
            useLiteralContent: true
          },
          optimizer: {
            enabled: true,
            runs: 500,
          },
        },
      },
      {
        version: "0.4.20",
      },
    ],
    // version: "0.8.17",
    // settings: {
    //   optimizer: {
    //     enabled: true,
    //     runs: 500,
    //   },
    // },
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS !== undefined,
    currency: "USD",
    coinmarketcap: { mnemonic: process.env.COINMARKETCAP_API_KEY ?? "c4aff0ef-8727-4e2d-8481-919ff0ae6a7f" }, // free key, not worth protecting
  },
  abiExporter: {
    path: "./abi",
    pretty: false,
    clear: true,
    runOnCompile: true,
    only: ["Errors$", "FlorinStaking$", "FlorinToken$", "FlorinTreasury$", "LoanVaultRegistry$", "LoanVault$", "Util$", "WhitelistManager$", "TestToken", "FlorinTestFaucet"],
  },
};
